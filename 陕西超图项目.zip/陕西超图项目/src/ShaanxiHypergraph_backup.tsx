import React, { useState, useEffect, useRef } from 'react';
import { Building2, Users, TrendingUp, AlertTriangle, Eye, FileText, Shield, Calendar, Network, MapPin, Globe, Search } from 'lucide-react';

const ShaanxiHypergraph = () => {
  const svgRef = useRef(null);
  const [selectedNode, setSelectedNode] = useState(null);
  const [hoveredNode, setHoveredNode] = useState(null);
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [riskLevel, setRiskLevel] = useState('all');
  const [viewMode, setViewMode] = useState('hypergraph');
  const [searchTerm, setSearchTerm] = useState('');
  const [showCities, setShowCities] = useState(true);

  // 基于陕西省筛选数据的真实企业（优化布局间距，选择15个以上代表性企业）
  const shaanxiCompanies = [
    // 西安市企业（拉开间距避免重叠）
    { id: 'c1', companyId: 563, stockCode: '000563', name: '陕国投A', type: 'company', 
      industry: '金融服务', province: '陕西省', city: '西安市', x: 180, y: 120, risk: 'medium' },
    { id: 'c2', companyId: 561, stockCode: '000561', name: '烽火电子', type: 'company', 
      industry: '电子设备', province: '陕西省', city: '西安市', x: 280, y: 140, risk: 'low' },
    { id: 'c3', companyId: 516, stockCode: '000516', name: '国际医学', type: 'company', 
      industry: '医疗服务', province: '陕西省', city: '西安市', x: 380, y: 120, risk: 'low' },
    { id: 'c4', companyId: 768, stockCode: '000768', name: '中航飞机', type: 'company', 
      industry: '航空装备', province: '陕西省', city: '西安市', x: 480, y: 140, risk: 'medium' },
    { id: 'c5', companyId: 610, stockCode: '000610', name: '西安旅游', type: 'company', 
      industry: '旅游服务', province: '陕西省', city: '西安市', x: 580, y: 120, risk: 'high' },
    { id: 'c6', companyId: 564, stockCode: '000564', name: '西安民生', type: 'company', 
      industry: '商业贸易', province: '陕西省', city: '西安市', x: 680, y: 140, risk: 'medium' },
    { id: 'c7', companyId: 721, stockCode: '000721', name: '西安饮食', type: 'company', 
      industry: '餐饮服务', province: '陕西省', city: '西安市', x: 780, y: 120, risk: 'high' },
    
    // 宝鸡市企业（拉开间距）
    { id: 'c8', companyId: 837, stockCode: '000837', name: '秦川机床', type: 'company', 
      industry: '机械设备', province: '陕西省', city: '宝鸡市', x: 120, y: 280, risk: 'medium' },
    { id: 'c9', companyId: 456, stockCode: '600456', name: '宝钛股份', type: 'company', 
      industry: '有色金属', province: '陕西省', city: '宝鸡市', x: 220, y: 300, risk: 'low' },
    { id: 'c10', companyId: 379, stockCode: '600379', name: '宝光股份', type: 'company', 
      industry: '电气设备', province: '陕西省', city: '宝鸡市', x: 320, y: 280, risk: 'medium' },
    
    // 咸阳市企业（拉开间距）
    { id: 'c11', companyId: 707, stockCode: '600707', name: '彩虹股份', type: 'company', 
      industry: '电子设备', province: '陕西省', city: '咸阳市', x: 880, y: 120, risk: 'high' },
    { id: 'c12', companyId: 217, stockCode: '600217', name: '中再资环', type: 'company', 
      industry: '环保工程', province: '陕西省', city: '咸阳市', x: 980, y: 140, risk: 'medium' },
    
    // 渭南市企业（拉开间距）
    { id: 'c13', companyId: 80, stockCode: '600080', name: '金花股份', type: 'company', 
      industry: '食品饮料', province: '陕西省', city: '渭南市', x: 820, y: 280, risk: 'medium' },
    { id: 'c14', companyId: 984, stockCode: '600984', name: '建设机械', type: 'company', 
      industry: '机械设备', province: '陕西省', city: '渭南市', x: 920, y: 300, risk: 'low' },
    
    // 延安市企业
    { id: 'c15', companyId: 248, stockCode: '600248', name: '延长化建', type: 'company', 
      industry: '化工建设', province: '陕西省', city: '延安市', x: 80, y: 450, risk: 'medium' },
    
    // 榆林市企业（拉开间距）
    { id: 'c16', companyId: 1225, stockCode: '601225', name: '陕西煤业', type: 'company', 
      industry: '煤炭开采', province: '陕西省', city: '榆林市', x: 420, y: 450, risk: 'low' },
    { id: 'c17', companyId: 1015, stockCode: '601015', name: '陕西黑猫', type: 'company', 
      industry: '化工原料', province: '陕西省', city: '榆林市', x: 520, y: 480, risk: 'medium' },
    
    // 汉中市企业
    { id: 'c18', companyId: 2267, stockCode: '002267', name: '陕天然气', type: 'company', 
      industry: '燃气供应', province: '陕西省', city: '汉中市', x: 280, y: 520, risk: 'low' },
    
    // 安康市企业
    { id: 'c19', companyId: 1369, stockCode: '601369', name: '陕鼓动力', type: 'company', 
      industry: '通用设备', province: '陕西省', city: '安康市', x: 180, y: 500, risk: 'medium' },
    
    // 铜川市企业
    { id: 'c20', companyId: 1179, stockCode: '601179', name: '中国西电', type: 'company', 
      industry: '电气设备', province: '陕西省', city: '铜川市', x: 720, y: 400, risk: 'low' }
  ];

  // 基于陕西省筛选数据的关键人员（补充所有公司的人员关系，优化布局间距）
  const shaanxiPersons = [
    // 西安市关键人员（拉开间距）
    { id: 'p1', personId: 110593, name: '王福喜', type: 'person', role: '董事长', 
      companies: ['c1'], province: '陕西省', city: '西安市', x: 160, y: 100, influence: 0.9 },
    { id: 'p2', personId: 125454, name: '钟宝申', type: 'person', role: '独立董事', 
      companies: ['c1', 'c16', 'c18'], province: '陕西省', city: '西安市', x: 400, y: 350, influence: 0.95 },
    { id: 'p3', personId: 133124, name: '吴佳健', type: 'person', role: '总经理', 
      companies: ['c2'], province: '陕西省', city: '西安市', x: 260, y: 100, influence: 0.8 },
    { id: 'p4', personId: 115211, name: '王瑞英', type: 'person', role: '独立董事', 
      companies: ['c1', 'c8'], province: '陕西省', city: '西安市', x: 150, y: 220, influence: 0.85 },
    { id: 'p5', personId: 128456, name: '李建华', type: 'person', role: '副总经理', 
      companies: ['c3'], province: '陕西省', city: '西安市', x: 360, y: 100, influence: 0.75 },
    { id: 'p6', personId: 134789, name: '张明', type: 'person', role: '技术总监', 
      companies: ['c4'], province: '陕西省', city: '西安市', x: 460, y: 100, influence: 0.8 },
    { id: 'p7', personId: 129876, name: '刘芳', type: 'person', role: '财务总监', 
      companies: ['c5'], province: '陕西省', city: '西安市', x: 560, y: 100, influence: 0.7 },
    { id: 'p8', personId: 135642, name: '陈志强', type: 'person', role: '总经理', 
      companies: ['c6'], province: '陕西省', city: '西安市', x: 660, y: 100, influence: 0.85 },
    { id: 'p9', personId: 127531, name: '王丽娟', type: 'person', role: '董事', 
      companies: ['c7'], province: '陕西省', city: '西安市', x: 760, y: 100, influence: 0.75 },
    
    // 宝鸡市关键人员（拉开间距）
    { id: 'p10', personId: 109582, name: '王东俊', type: 'person', role: '董事长', 
      companies: ['c8'], province: '陕西省', city: '宝鸡市', x: 100, y: 260, influence: 0.8 },
    { id: 'p11', personId: 137233, name: '牛婷婷', type: 'person', role: '财务总监', 
      companies: ['c9', 'c10'], province: '陕西省', city: '宝鸡市', x: 270, y: 350, influence: 0.75 },
    { id: 'p12', personId: 138654, name: '赵国庆', type: 'person', role: '副总经理', 
      companies: ['c10'], province: '陕西省', city: '宝鸡市', x: 300, y: 260, influence: 0.7 },
    
    // 咸阳市关键人员（拉开间距）
    { id: 'p13', personId: 128019, name: '陈愉洲', type: 'person', role: '技术总监', 
      companies: ['c11', 'c12'], province: '陕西省', city: '咸阳市', x: 930, y: 180, influence: 0.8 },
    { id: 'p14', personId: 139876, name: '孙建军', type: 'person', role: '董事长', 
      companies: ['c12'], province: '陕西省', city: '咸阳市', x: 960, y: 120, influence: 0.85 },
    
    // 渭南市关键人员（拉开间距）
    { id: 'p15', personId: 126499, name: '马英勤', type: 'person', role: '监事', 
      companies: ['c13', 'c14'], province: '陕西省', city: '渭南市', x: 870, y: 320, influence: 0.7 },
    { id: 'p16', personId: 141234, name: '李秀梅', type: 'person', role: '总经理', 
      companies: ['c14'], province: '陕西省', city: '渭南市', x: 900, y: 280, influence: 0.75 },
    
    // 延安市关键人员
    { id: 'p17', personId: 144420, name: '刘明义', type: 'person', role: '董事', 
      companies: ['c15'], province: '陕西省', city: '延安市', x: 60, y: 430, influence: 0.75 },
    
    // 榆林市关键人员（拉开间距）
    { id: 'p18', personId: 132133, name: '陈盛霞', type: 'person', role: '副总经理', 
      companies: ['c16', 'c17'], province: '陕西省', city: '榆林市', x: 470, y: 500, influence: 0.8 },
    { id: 'p19', personId: 142567, name: '杨志华', type: 'person', role: '董事长', 
      companies: ['c17'], province: '陕西省', city: '榆林市', x: 500, y: 460, influence: 0.85 },
    
    // 汉中市关键人员
    { id: 'p20', personId: 133158, name: '林绍山', type: 'person', role: '独立董事', 
      companies: ['c18', 'c19'], province: '陕西省', city: '汉中市', x: 230, y: 540, influence: 0.85 },
    
    // 安康市关键人员
    { id: 'p21', personId: 143789, name: '周建国', type: 'person', role: '总经理', 
      companies: ['c19'], province: '陕西省', city: '安康市', x: 160, y: 480, influence: 0.8 },
    
    // 铜川市关键人员
    { id: 'p22', personId: 132135, name: '岳朝阳', type: 'person', role: '总工程师', 
      companies: ['c20'], province: '陕西省', city: '铜川市', x: 700, y: 380, influence: 0.75 }
  ];

  // 基于真实关系数据的连接（补充所有公司的人员关系）
  const shaanxiRelationships = [
    // 西安市企业人员关系
    { source: 'c1', target: 'p1', type: 'chairman', weight: 1.0, edgeType: 4 },
    { source: 'c2', target: 'p3', type: 'ceo', weight: 1.0, edgeType: 4 },
    { source: 'c3', target: 'p5', type: 'vice_manager', weight: 0.9, edgeType: 2 },
    { source: 'c4', target: 'p6', type: 'technical_director', weight: 0.9, edgeType: 3 },
    { source: 'c5', target: 'p7', type: 'financial_director', weight: 0.8, edgeType: 2 },
    { source: 'c6', target: 'p8', type: 'ceo', weight: 1.0, edgeType: 4 },
    { source: 'c7', target: 'p9', type: 'director', weight: 0.8, edgeType: 1 },
    
    // 宝鸡市企业人员关系
    { source: 'c8', target: 'p10', type: 'chairman', weight: 1.0, edgeType: 4 },
    { source: 'c9', target: 'p11', type: 'financial_director', weight: 0.8, edgeType: 2 },
    { source: 'c10', target: 'p11', type: 'financial_director', weight: 0.7, edgeType: 2 },
    { source: 'c10', target: 'p12', type: 'vice_manager', weight: 0.8, edgeType: 2 },
    
    // 咸阳市企业人员关系
    { source: 'c11', target: 'p13', type: 'technical_director', weight: 0.8, edgeType: 3 },
    { source: 'c12', target: 'p13', type: 'technical_director', weight: 0.6, edgeType: 3 },
    { source: 'c12', target: 'p14', type: 'chairman', weight: 1.0, edgeType: 4 },
    
    // 渭南市企业人员关系
    { source: 'c13', target: 'p15', type: 'supervisor', weight: 0.7, edgeType: 1 },
    { source: 'c14', target: 'p15', type: 'supervisor', weight: 0.6, edgeType: 1 },
    { source: 'c14', target: 'p16', type: 'ceo', weight: 1.0, edgeType: 4 },
    
    // 延安市企业人员关系
    { source: 'c15', target: 'p17', type: 'director', weight: 0.7, edgeType: 1 },
    
    // 榆林市企业人员关系
    { source: 'c16', target: 'p18', type: 'vice_manager', weight: 0.8, edgeType: 2 },
    { source: 'c17', target: 'p18', type: 'vice_manager', weight: 0.7, edgeType: 2 },
    { source: 'c17', target: 'p19', type: 'chairman', weight: 1.0, edgeType: 4 },
    
    // 汉中市企业人员关系
    { source: 'c18', target: 'p20', type: 'independent_director', weight: 0.8, edgeType: 0 },
    { source: 'c19', target: 'p20', type: 'independent_director', weight: 0.7, edgeType: 0 },
    { source: 'c19', target: 'p21', type: 'ceo', weight: 1.0, edgeType: 4 },
    
    // 铜川市企业人员关系
    { source: 'c20', target: 'p22', type: 'chief_engineer', weight: 0.8, edgeType: 3 },
    
    // 独立董事跨公司关系（超图核心特征）
    { source: 'p2', target: 'c1', type: 'independent_director', weight: 0.9, edgeType: 0 },
    { source: 'p2', target: 'c16', type: 'independent_director', weight: 0.8, edgeType: 0 },
    { source: 'p2', target: 'c18', type: 'independent_director', weight: 0.7, edgeType: 0 },
    { source: 'p4', target: 'c1', type: 'independent_director', weight: 0.8, edgeType: 0 },
    { source: 'p4', target: 'c8', type: 'independent_director', weight: 0.7, edgeType: 0 },
    
    // 同城企业间的业务关系
    { source: 'c1', target: 'c2', type: 'regional_cooperation', weight: 0.4, edgeType: 6 },
    { source: 'c2', target: 'c3', type: 'regional_cooperation', weight: 0.3, edgeType: 6 },
    { source: 'c3', target: 'c4', type: 'regional_cooperation', weight: 0.5, edgeType: 6 },
    { source: 'c4', target: 'c5', type: 'regional_cooperation', weight: 0.3, edgeType: 6 },
    { source: 'c5', target: 'c6', type: 'regional_cooperation', weight: 0.4, edgeType: 6 },
    { source: 'c6', target: 'c7', type: 'regional_cooperation', weight: 0.3, edgeType: 6 },
    { source: 'c8', target: 'c9', type: 'regional_cooperation', weight: 0.4, edgeType: 6 },
    { source: 'c9', target: 'c10', type: 'regional_cooperation', weight: 0.3, edgeType: 6 },
    { source: 'c11', target: 'c12', type: 'regional_cooperation', weight: 0.4, edgeType: 6 },
    { source: 'c13', target: 'c14', type: 'regional_cooperation', weight: 0.3, edgeType: 6 },
    { source: 'c16', target: 'c17', type: 'industry_cooperation', weight: 0.6, edgeType: 8 },
    { source: 'c18', target: 'c19', type: 'regional_cooperation', weight: 0.4, edgeType: 6 }
  ];

  // 陕西省各市超边（市级别聚类，适应新布局）
  const cityHyperedges = {
    '西安市': { 
      companies: ['c1', 'c2', 'c3', 'c4', 'c5', 'c6', 'c7'], 
      persons: ['p1', 'p2', 'p3', 'p4', 'p5', 'p6', 'p7', 'p8', 'p9'], 
      color: '#ef4444', 
      center: {x: 480, y: 130} 
    },
    '宝鸡市': { 
      companies: ['c8', 'c9', 'c10'], 
      persons: ['p10', 'p11', 'p12'], 
      color: '#3b82f6', 
      center: {x: 220, y: 290} 
    },
    '咸阳市': { 
      companies: ['c11', 'c12'], 
      persons: ['p13', 'p14'], 
      color: '#f59e0b', 
      center: {x: 930, y: 150} 
    },
    '渭南市': { 
      companies: ['c13', 'c14'], 
      persons: ['p15', 'p16'], 
      color: '#10b981', 
      center: {x: 870, y: 290} 
    },
    '延安市': { 
      companies: ['c15'], 
      persons: ['p17'], 
      color: '#8b5cf6', 
      center: {x: 80, y: 450} 
    },
    '榆林市': { 
      companies: ['c16', 'c17'], 
      persons: ['p18', 'p19'], 
      color: '#ec4899', 
      center: {x: 470, y: 470} 
    },
    '汉中市': { 
      companies: ['c18'], 
      persons: ['p20'], 
      color: '#06b6d4', 
      center: {x: 255, y: 530} 
    },
    '安康市': { 
      companies: ['c19'], 
      persons: ['p21'], 
      color: '#84cc16', 
      center: {x: 170, y: 490} 
    },
    '铜川市': { 
      companies: ['c20'], 
      persons: ['p22'], 
      color: '#f97316', 
      center: {x: 710, y: 390} 
    }
  };

  // 关系类型映射
  const edgeTypeMapping = {
    0: { name: '独立董事', color: '#8b5cf6' },
    1: { name: '监事关系', color: '#10b981' },
    2: { name: '财务管理', color: '#f59e0b' },
    3: { name: '技术管理', color: '#06b6d4' },
    4: { name: '高管关系', color: '#ef4444' },
    5: { name: '任职关系', color: '#84cc16' },
    6: { name: '区域合作', color: '#ec4899' },
    7: { name: '竞争关系', color: '#f97316' },
    8: { name: '行业合作', color: '#6366f1' }
  };

  const getNodeColor = (node) => {
    if (node.type === 'company') {
      switch (node.risk) {
        case 'high': return '#ef4444';
        case 'medium': return '#f59e0b';
        case 'low': return '#10b981';
        default: return '#6b7280';
      }
    }
    // 人员节点根据影响力着色
    const influence = node.influence || 0.5;
    if (influence > 0.8) return '#8b5cf6';
    if (influence > 0.6) return '#a78bfa';
    return '#c4b5fd';
  };

  const getRelationshipColor = (relationship) => {
    return edgeTypeMapping[relationship.edgeType]?.color || '#6b7280';
  };

  const filteredCompanies = shaanxiCompanies.filter(company => {
    const matchesCategory = selectedCategory === 'all' || company.industry === selectedCategory;
    const matchesRisk = riskLevel === 'all' || company.risk === riskLevel;
    const matchesSearch = searchTerm === '' || 
      company.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      company.stockCode.includes(searchTerm);
    return matchesCategory && matchesRisk && matchesSearch;
  });

  const filteredPersons = shaanxiPersons.filter(person => {
    const matchesSearch = searchTerm === '' || 
      person.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      person.role.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesSearch;
  });

  const NodeTooltip = ({ node, x, y }) => {
    if (!node) return null;
    
    return (
      <div 
        className="absolute bg-white border border-gray-300 rounded-lg shadow-lg p-3 z-10 min-w-64"
        style={{ left: x + 10, top: y - 10 }}
      >
        <div className="font-bold text-sm mb-2">{node.name}</div>
        {node.type === 'company' && (
          <div className="text-xs space-y-1">
            <div className="flex items-center gap-2">
              <Building2 className="w-3 h-3" />
              <span>股票代码: {node.stockCode}</span>
            </div>
            <div className="flex items-center gap-2">
              <TrendingUp className="w-3 h-3" />
              <span>行业: {node.industry}</span>
            </div>
            <div className="flex items-center gap-2">
              <MapPin className="w-3 h-3" />
              <span>地区: {node.city}</span>
            </div>
            <div className="flex items-center gap-2">
              <AlertTriangle className="w-3 h-3" />
              <span>风险等级: {node.risk}</span>
            </div>
          </div>
        )}
        {node.type === 'person' && (
          <div className="text-xs space-y-1">
            <div className="flex items-center gap-2">
              <Users className="w-3 h-3" />
              <span>ID: {node.personId}</span>
            </div>
            <div className="flex items-center gap-2">
              <Shield className="w-3 h-3" />
              <span>职位: {node.role}</span>
            </div>
            <div className="flex items-center gap-2">
              <MapPin className="w-3 h-3" />
              <span>地区: {node.city}</span>
            </div>
            <div className="flex items-center gap-2">
              <Network className="w-3 h-3" />
              <span>影响力: {((node.influence || 0.5) * 100).toFixed(0)}%</span>
            </div>
            <div className="flex items-center gap-2">
              <Building2 className="w-3 h-3" />
              <span>关联企业: {node.companies?.length || 0}个</span>
            </div>
          </div>
        )}
      </div>
    );
  };

  return (
    <div className="w-full h-screen bg-gray-50 flex flex-col">
      {/* 控制面板 */}
      <div className="bg-white border-b border-gray-200 p-4">
        <div className="flex items-center justify-between mb-4">
          <h1 className="text-xl font-bold text-gray-800">陕西省金融风险知识超图可视化系统</h1>
          <div className="flex items-center gap-2 text-sm text-gray-600">
            <Globe className="w-4 h-4" />
            <span>20个企业 • 22个人员 • 9个城市</span>
          </div>
        </div>
        
        <div className="flex items-center gap-4 flex-wrap">
          <div className="flex items-center gap-2">
            <Search className="w-4 h-4 text-gray-500" />
            <input
              type="text"
              placeholder="搜索企业或人员..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="border border-gray-300 rounded px-2 py-1 text-sm w-48"
            />
          </div>
          
          <div className="flex items-center gap-2">
            <label className="text-sm font-medium">行业:</label>
            <select 
              value={selectedCategory} 
              onChange={(e) => setSelectedCategory(e.target.value)}
              className="border border-gray-300 rounded px-2 py-1 text-sm"
            >
              <option value="all">全部</option>
              <option value="金融服务">金融服务</option>
              <option value="电子设备">电子设备</option>
              <option value="机械设备">机械设备</option>
              <option value="医疗服务">医疗服务</option>
              <option value="航空装备">航空装备</option>
              <option value="化工原料">化工原料</option>
            </select>
          </div>
          
          <div className="flex items-center gap-2">
            <label className="text-sm font-medium">风险:</label>
            <select 
              value={riskLevel} 
              onChange={(e) => setRiskLevel(e.target.value)}
              className="border border-gray-300 rounded px-2 py-1 text-sm"
            >
              <option value="all">全部</option>
              <option value="high">高风险</option>
              <option value="medium">中风险</option>
              <option value="low">低风险</option>
            </select>
          </div>
          
          <div className="flex items-center gap-2">
            <label className="text-sm font-medium">城市超边:</label>
            <input
              type="checkbox"
              checked={showCities}
              onChange={(e) => setShowCities(e.target.checked)}
              className="rounded"
            />
          </div>
        </div>
      </div>

      {/* 主要可视化区域 */}
      <div className="flex-1 flex">
        {/* 左侧图例 */}
        <div className="w-64 bg-white border-r border-gray-200 p-4 overflow-y-auto">
          <h3 className="font-bold text-sm mb-3">图例说明</h3>
          
          <div className="space-y-4">
            <div>
              <h4 className="font-medium text-xs mb-2">节点类型</h4>
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <Building2 className="w-4 h-4 text-blue-500" />
                  <span className="text-xs">企业 (20个)</span>
                </div>
                <div className="flex items-center gap-2">
                  <Users className="w-4 h-4 text-purple-500" />
                  <span className="text-xs">人员 (22个)</span>
                </div>
              </div>
            </div>

            <div>
              <h4 className="font-medium text-xs mb-2">风险等级</h4>
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 bg-red-500 rounded-full"></div>
                  <span className="text-xs">高风险</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 bg-yellow-500 rounded-full"></div>
                  <span className="text-xs">中风险</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 bg-green-500 rounded-full"></div>
                  <span className="text-xs">低风险</span>
                </div>
              </div>
            </div>

            <div>
              <h4 className="font-medium text-xs mb-2">关系类型</h4>
              <div className="space-y-1 text-xs max-h-32 overflow-y-auto">
                {Object.entries(edgeTypeMapping).map(([type, info]) => (
                  <div key={type} className="flex items-center gap-2">
                    <div className="w-4 h-0.5" style={{ backgroundColor: info.color }}></div>
                    <span>{info.name}</span>
                  </div>
                ))}
              </div>
            </div>

            <div>
              <h4 className="font-medium text-xs mb-2">城市分布</h4>
              <div className="space-y-1 text-xs max-h-40 overflow-y-auto">
                {Object.entries(cityHyperedges).map(([city, info]) => (
                  <div key={city} className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <div className="w-3 h-3 rounded-full" style={{ backgroundColor: info.color }}></div>
                      <span className="text-xs">{city}</span>
                    </div>
                    <span className="text-xs text-gray-500">
                      {info.companies.length}企业
                    </span>
                  </div>
                ))}
              </div>
            </div>

            <div>
              <h4 className="font-medium text-xs mb-2">数据统计</h4>
              <div className="text-xs space-y-1 bg-gray-50 p-2 rounded">
                <div>筛选企业: {filteredCompanies.length}/20</div>
                <div>显示人员: {filteredPersons.length}/22</div>
                <div>关系总数: {shaanxiRelationships.length}条</div>
                <div>覆盖城市: 9个</div>
              </div>
            </div>
          </div>
        </div>

        {/* 中心超图可视化 */}
        <div className="flex-1 relative">
          <svg 
            ref={svgRef} 
            width="100%" 
            height="100%" 
            className="bg-gray-50"
            viewBox="0 0 1200 600"
          >
            {/* 城市超边背景 */}
            {showCities && Object.entries(cityHyperedges).map(([city, info]) => {
              // 根据城市动态计算椭圆大小
              let rx = 90, ry = 70;
              if (city === '西安市') {
                rx = 320; // 扩大半径以包含所有西安企业 (180-780的范围)
                ry = 80;
              } else if (city === '宝鸡市') {
                rx = 120;
                ry = 70;
              } else if (city === '咸阳市') {
                rx = 80;
                ry = 60;
              } else if (city === '渭南市') {
                rx = 80;
                ry = 60;
              } else if (city === '榆林市') {
                rx = 80;
                ry = 60;
              }
              
              return (
                <g key={city}>
                  <ellipse
                    cx={info.center.x}
                    cy={info.center.y}
                    rx={rx}
                    ry={ry}
                    fill={info.color}
                    opacity="0.1"
                    stroke={info.color}
                    strokeWidth="2"
                    strokeDasharray="5,5"
                  />
                  <text
                    x={info.center.x}
                    y={info.center.y - ry - 10}
                    textAnchor="middle"
                    className="text-xs font-medium"
                    fill={info.color}
                  >
                    {city}
                  </text>
                </g>
              );
            })}

            {/* 关系连线 */}
            {shaanxiRelationships.map((rel, index) => {
              const sourceNode = [...filteredCompanies, ...filteredPersons].find(n => n.id === rel.source);
              const targetNode = [...filteredCompanies, ...filteredPersons].find(n => n.id === rel.target);
              
              if (!sourceNode || !targetNode) return null;
              
              return (
                <line
                  key={index}
                  x1={sourceNode.x}
                  y1={sourceNode.y}
                  x2={targetNode.x}
                  y2={targetNode.y}
                  stroke={getRelationshipColor(rel)}
                  strokeWidth={rel.weight * 2 + 1}
                  opacity={0.6}
                />
              );
            })}

            {/* 企业节点 */}
            {filteredCompanies.map((company) => (
              <g key={company.id}>
                <circle
                  cx={company.x}
                  cy={company.y}
                  r="20"
                  fill={getNodeColor(company)}
                  stroke="white"
                  strokeWidth="3"
                  opacity={hoveredNode === company.id ? 1 : 0.8}
                  className="cursor-pointer"
                  onMouseEnter={() => setHoveredNode(company.id)}
                  onMouseLeave={() => setHoveredNode(null)}
                  onClick={() => setSelectedNode(company)}
                />
                <Building2 
                  x={company.x - 8} 
                  y={company.y - 8} 
                  width="16" 
                  height="16" 
                  fill="white"
                  className="pointer-events-none"
                />
                <text
                  x={company.x}
                  y={company.y + 35}
                  textAnchor="middle"
                  className="text-xs font-medium fill-gray-700"
                >
                  {company.name.length > 6 ? company.name.substring(0, 6) + '...' : company.name}
                </text>
                <text
                  x={company.x}
                  y={company.y + 47}
                  textAnchor="middle"
                  className="text-xs fill-gray-500"
                >
                  {company.stockCode}
                </text>
              </g>
            ))}

            {/* 人员节点 */}
            {filteredPersons.map((person) => (
              <g key={person.id}>
                <circle
                  cx={person.x}
                  cy={person.y}
                  r={14 + (person.influence || 0.5) * 8}
                  fill={getNodeColor(person)}
                  stroke="white"
                  strokeWidth="2"
                  opacity={hoveredNode === person.id ? 1 : 0.8}
                  className="cursor-pointer"
                  onMouseEnter={() => setHoveredNode(person.id)}
                  onMouseLeave={() => setHoveredNode(null)}
                  onClick={() => setSelectedNode(person)}
                />
                <Users 
                  x={person.x - 7} 
                  y={person.y - 7} 
                  width="14" 
                  height="14" 
                  fill="white"
                  className="pointer-events-none"
                />
                <text
                  x={person.x}
                  y={person.y + 30}
                  textAnchor="middle"
                  className="text-xs fill-gray-700"
                >
                  {person.name}
                </text>
                <text
                  x={person.x}
                  y={person.y + 42}
                  textAnchor="middle"
                  className="text-xs fill-gray-500"
                >
                  {person.role}
                </text>
              </g>
            ))}
          </svg>

          {/* 工具提示 */}
          {hoveredNode && (
            <NodeTooltip
              node={[...filteredCompanies, ...filteredPersons].find(n => n.id === hoveredNode)}
              x={300}
              y={200}
            />
          )}
        </div>

        {/* 右侧详情面板 */}
        <div className="w-80 bg-white border-l border-gray-200 p-4 overflow-y-auto">
          <h3 className="font-bold text-sm mb-3">详细信息</h3>
          
          {selectedNode ? (
            <div className="space-y-4">
              <div>
                <h4 className="font-medium text-sm mb-2">{selectedNode.name}</h4>
                <div className="text-xs text-gray-600 space-y-1">
                  <div>类型: {selectedNode.type === 'company' ? '企业' : '人员'}</div>
                  {selectedNode.stockCode && <div>代码: {selectedNode.stockCode}</div>}
                  {selectedNode.personId && <div>ID: {selectedNode.personId}</div>}
                  {selectedNode.industry && <div>行业: {selectedNode.industry}</div>}
                  {selectedNode.role && <div>职位: {selectedNode.role}</div>}
                  {selectedNode.city && <div>城市: {selectedNode.city}</div>}
                  {selectedNode.risk && <div>风险: {selectedNode.risk}</div>}
                  {selectedNode.influence && <div>影响力: {(selectedNode.influence * 100).toFixed(0)}%</div>}
                </div>
              </div>

              <div>
                <h4 className="font-medium text-sm mb-2">关联关系</h4>
                <div className="space-y-1 text-xs">
                  {shaanxiRelationships
                    .filter(rel => rel.source === selectedNode.id || rel.target === selectedNode.id)
                    .map((rel, index) => {
                      const isSource = rel.source === selectedNode.id;
                      const otherNodeId = isSource ? rel.target : rel.source;
                      const otherNode = [...filteredCompanies, ...filteredPersons].find(n => n.id === otherNodeId);
                      
                      if (!otherNode) return null;
                      
                      return (
                        <div key={index} className="flex items-center gap-2 p-2 bg-gray-50 rounded">
                          <div 
                            className="w-2 h-2 rounded-full"
                            style={{ backgroundColor: getRelationshipColor(rel) }}
                          ></div>
                          <div className="flex-1">
                            <div className="font-medium">{otherNode.name}</div>
                            <div className="text-gray-500">
                              {edgeTypeMapping[rel.edgeType]?.name || rel.type} 
                              {rel.weight && ` (${(rel.weight * 100).toFixed(0)}%)`}
                            </div>
                          </div>
                        </div>
                      );
                    })}
                </div>
              </div>

              {selectedNode.type === 'person' && selectedNode.companies && (
                <div>
                  <h4 className="font-medium text-sm mb-2">关联企业</h4>
                  <div className="space-y-1 text-xs">
                    {selectedNode.companies.map(companyId => {
                      const company = filteredCompanies.find(c => c.id === companyId);
                      return company ? (
                        <div key={companyId} className="p-2 bg-blue-50 rounded">
                          <div className="font-medium">{company.name}</div>
                          <div className="text-gray-500">{company.stockCode} • {company.industry}</div>
                        </div>
                      ) : null;
                    })}
                  </div>
                </div>
              )}

              <div>
                <h4 className="font-medium text-sm mb-2">城市超边</h4>
                {selectedNode.city && cityHyperedges[selectedNode.city] && (
                  <div className="p-2 rounded" style={{ backgroundColor: cityHyperedges[selectedNode.city].color + '20' }}>
                    <div className="font-medium text-sm">{selectedNode.city}</div>
                    <div className="text-xs text-gray-600 mt-1">
                      <div>企业: {cityHyperedges[selectedNode.city].companies.length}个</div>
                      <div>人员: {cityHyperedges[selectedNode.city].persons.length}个</div>
                    </div>
                  </div>
                )}
              </div>
            </div>
          ) : (
            <div className="text-sm text-gray-500 text-center py-8">
              <Network className="w-12 h-12 mx-auto mb-4 text-gray-300" />
              <div>点击节点查看详细信息</div>
              <div className="mt-2 text-xs">基于陕西省真实筛选数据的超图</div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default ShaanxiHypergraph;
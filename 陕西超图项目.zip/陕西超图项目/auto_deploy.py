#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
陕西超图项目自动部署脚本
作者：AI助手
功能：自动检查环境、安装依赖、启动开发服务器
"""

import os
import sys
import subprocess
import time
import webbrowser
from pathlib import Path

def check_command_exists(command):
    """检查命令是否存在"""
    try:
        subprocess.run([command, '--version'], capture_output=True, check=True)
        return True
    except (subprocess.CalledProcessError, FileNotFoundError):
        return False

def install_nodejs():
    """提示用户安装Node.js"""
    print("❌ 未检测到Node.js，请先安装Node.js")
    print("📥 请访问 https://nodejs.org/ 下载并安装Node.js")
    print("💡 建议安装LTS版本（长期支持版本）")
    input("安装完成后按回车键继续...")
    
    if not check_command_exists('node'):
        print("❌ 仍未检测到Node.js，请重新安装后再运行此脚本")
        sys.exit(1)

def run_command(command, description):
    """运行命令并显示进度"""
    print(f"🔄 {description}...")
    try:
        result = subprocess.run(command, shell=True, check=True, 
                              capture_output=True, text=True, encoding='utf-8')
        print(f"✅ {description}完成")
        return True
    except subprocess.CalledProcessError as e:
        print(f"❌ {description}失败: {e}")
        if e.stdout:
            print(f"输出: {e.stdout}")
        if e.stderr:
            print(f"错误: {e.stderr}")
        return False

def main():
    """主函数"""
    print("🚀 陕西超图项目自动部署脚本")
    print("=" * 50)
    
    # 检查当前目录
    current_dir = Path.cwd()
    print(f"📁 当前目录: {current_dir}")
    
    # 检查必要文件
    required_files = ['package.json', 'src/ShaanxiHypergraph.tsx']
    missing_files = []
    
    for file in required_files:
        if not (current_dir / file).exists():
            missing_files.append(file)
    
    if missing_files:
        print(f"❌ 缺少必要文件: {', '.join(missing_files)}")
        print("请确保在正确的项目目录中运行此脚本")
        sys.exit(1)
    
    print("✅ 项目文件检查通过")
    
    # 检查Node.js
    print("\n🔍 检查Node.js环境...")
    if not check_command_exists('node'):
        install_nodejs()
    else:
        print("✅ Node.js已安装")
    
    # 检查npm
    if not check_command_exists('npm'):
        print("❌ npm未找到，请重新安装Node.js")
        sys.exit(1)
    else:
        print("✅ npm已安装")
    
    # 安装依赖
    print("\n📦 安装项目依赖...")
    if not run_command('npm install', '安装依赖'):
        print("❌ 依赖安装失败，请检查网络连接或手动运行 'npm install'")
        sys.exit(1)
    
    # 启动开发服务器
    print("\n🌐 启动开发服务器...")
    print("⏳ 正在启动，请稍候...")
    
    try:
        # 启动开发服务器（非阻塞）
        process = subprocess.Popen(['npm', 'run', 'dev'], 
                                 stdout=subprocess.PIPE, 
                                 stderr=subprocess.PIPE,
                                 text=True, encoding='utf-8')
        
        # 等待服务器启动
        time.sleep(5)
        
        # 检查进程是否还在运行
        if process.poll() is None:
            print("✅ 开发服务器启动成功！")
            print("🌐 项目地址: http://localhost:5173")
            print("📱 或者: http://localhost:3000")
            print("\n💡 提示:")
            print("  - 浏览器会自动打开项目页面")
            print("  - 按 Ctrl+C 停止服务器")
            print("  - 修改代码后页面会自动刷新")
            
            # 自动打开浏览器
            time.sleep(2)
            try:
                webbrowser.open('http://localhost:5173')
            except:
                try:
                    webbrowser.open('http://localhost:3000')
                except:
                    print("⚠️ 无法自动打开浏览器，请手动访问上述地址")
            
            # 等待用户停止
            try:
                process.wait()
            except KeyboardInterrupt:
                print("\n🛑 正在停止服务器...")
                process.terminate()
                process.wait()
                print("✅ 服务器已停止")
        else:
            print("❌ 服务器启动失败")
            stdout, stderr = process.communicate()
            if stdout:
                print(f"输出: {stdout}")
            if stderr:
                print(f"错误: {stderr}")
    
    except Exception as e:
        print(f"❌ 启动过程中出现错误: {e}")
        print("\n🔧 手动启动方法:")
        print("1. 打开命令行/终端")
        print("2. 进入项目目录")
        print("3. 运行: npm install")
        print("4. 运行: npm run dev")

if __name__ == '__main__':
    main()

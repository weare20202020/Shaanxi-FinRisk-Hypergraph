import React from 'react'
import ShaanxiHypergraph from './ShaanxiHypergraph'

function App() {
  return (
    <div className="App">
      <ShaanxiHypergraph />
    </div>
  )
}

export default App
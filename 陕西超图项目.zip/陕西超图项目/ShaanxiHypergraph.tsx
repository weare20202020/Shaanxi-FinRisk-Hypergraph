import React, { useState, useEffect, useRef } from 'react';
import { Building2, Users, TrendingUp, AlertTriangle, Eye, FileText, Shield, Calendar, Network, MapPin, Globe, Search } from 'lucide-react';

const ShaanxiHypergraph = () => {
  const svgRef = useRef(null);
  const [selectedNode, setSelectedNode] = useState(null);
  const [hoveredNode, setHoveredNode] = useState(null);
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [riskLevel, setRiskLevel] = useState('all');
  const [viewMode, setViewMode] = useState('hypergraph');
  const [searchTerm, setSearchTerm] = useState('');
  const [showCities, setShowCities] = useState(true);
  const [hyperedgeType, setHyperedgeType] = useState('city'); // 'city', 'industry', 'both'
  
  // 拖拽相关状态
  const [isDragging, setIsDragging] = useState(false);
  const [draggedNode, setDraggedNode] = useState(null);
  const [dragOffset, setDragOffset] = useState({ x: 0, y: 0 });
  // 精选核心企业数据（根据图片重新调整坐标位置）
  const initialCompanies = [
    // 金融服务行业 - 左上角区域
    { id: 'c1', companyId: 563, stockCode: '000563', name: '陕国投A', type: 'company', 
      industry: '金融服务', province: '陕西省', city: '西安市', x: 265, y: 155, risk: 'medium' },
    
    // 电子设备行业 - 上方区域
    { id: 'c2', companyId: 561, stockCode: '000561', name: '烽火电子', type: 'company', 
      industry: '电子设备', province: '陕西省', city: '西安市', x: 482, y: 123, risk: 'low' },
    { id: 'c3', companyId: 768, stockCode: '000768', name: '中航飞机', type: 'company', 
      industry: '机械设备', province: '陕西省', city: '西安市', x: 547, y: 145, risk: 'medium' },
    { id: 'c4', companyId: 707, stockCode: '600707', name: '彩虹股份', type: 'company', 
      industry: '电子设备', province: '陕西省', city: '西安市', x: 598, y: 173, risk: 'high' },
    { id: 'c14', companyId: 2208, stockCode: '002208', name: '合众思壮', type: 'company', 
      industry: '电子设备', province: '陕西省', city: '西安市', x: 654, y: 155, risk: 'medium' },
    
    // 有色金属行业 - 左侧中部区域
    { id: 'c6', companyId: 456, stockCode: '600456', name: '宝钛股份', type: 'company', 
      industry: '有色金属', province: '陕西省', city: '宝鸡市', x: 190, y: 366, risk: 'low' },
    
    // 机械设备行业 - 中部区域
    { id: 'c7', companyId: 984, stockCode: '600984', name: '建设机械', type: 'company', 
      industry: '机械设备', province: '陕西省', city: '宝鸡市', x: 390, y: 347, risk: 'low' },
    
    // 电气设备行业 - 右侧区域
     { id: 'c8', companyId: 379, stockCode: '600379', name: '宝光股份', type: 'company', 
       industry: '电气设备', province: '陕西省', city: '宝鸡市', x: 654, y: 371, risk: 'medium' },
     { id: 'c12', companyId: 1179, stockCode: '601179', name: '中国西电', type: 'company', 
       industry: '电气设备', province: '陕西省', city: '榆林市', x: 590, y: 518, risk: 'low' },
     
     // 能源化工行业 - 下方区域
     { id: 'c9', companyId: 1225, stockCode: '601225', name: '陕西煤业', type: 'company', 
       industry: '能源化工', province: '陕西省', city: '榆林市', x: 334, y: 503, risk: 'low' },
     { id: 'c10', companyId: 1015, stockCode: '601015', name: '陕西黑猫', type: 'company', 
       industry: '能源化工', province: '陕西省', city: '榆林市', x: 283, y: 578, risk: 'medium' },
     { id: 'c11', companyId: 248, stockCode: '600248', name: '延长化建', type: 'company', 
       industry: '能源化工', province: '陕西省', city: '榆林市', x: 515, y: 544, risk: 'medium' },
     { id: 'c15', companyId: 1088, stockCode: '601088', name: '中国神华', type: 'company', 
       industry: '能源化工', province: '陕西省', city: '榆林市', x: 459, y: 586, risk: 'low' }
  ];

  // 核心人员数据（根据新的企业布局调整坐标）
  const initialPersons = [
    // 跨行业独立董事（核心连接节点）- 中央连接区域
    { id: 'p1', personId: 125454, name: '钟宝申', type: 'person', role: '独立董事', 
      companies: ['c1', 'c4', 'c9'], province: '陕西省', city: '西安市', x: 400, y: 350, influence: 0.95 },
    { id: 'p2', personId: 115211, name: '王瑞英', type: 'person', role: '独立董事', 
      companies: ['c2', 'c6', 'c12'], province: '陕西省', city: '西安市', x: 450, y: 300, influence: 0.9 },
    
    // 金融服务行业人员 - 左上角区域
    { id: 'p3', personId: 110593, name: '王福喜', type: 'person', role: '董事长', 
      companies: ['c1'], province: '陕西省', city: '西安市', x: 150, y: 95, influence: 0.9 },
    
    // 电子设备行业人员 - 右上角区域
    { id: 'p4', personId: 133124, name: '吴佳健', type: 'person', role: '总经理', 
      companies: ['c2'], province: '陕西省', city: '西安市', x: 520, y: 80, influence: 0.8 },
    { id: 'p5', personId: 134789, name: '张明', type: 'person', role: '技术总监', 
      companies: ['c3', 'c4'], province: '陕西省', city: '西安市', x: 670, y: 110, influence: 0.85 },
    { id: 'p13', personId: 156789, name: '张科技', type: 'person', role: '研发总监', 
      companies: ['c14', 'c3'], province: '陕西省', city: '西安市', x: 650, y: 200, influence: 0.8 },
    
    // 有色金属和机械设备行业人员 - 中部区域
    { id: 'p7', personId: 137233, name: '牛婷婷', type: 'person', role: '财务总监', 
      companies: ['c6', 'c7'], province: '陕西省', city: '宝鸡市', x: 180, y: 350, influence: 0.75 },
    
    // 电气设备行业人员 - 右侧区域
    { id: 'p8', personId: 138654, name: '赵国庆', type: 'person', role: '副总经理', 
      companies: ['c8'], province: '陕西省', city: '宝鸡市', x: 720, y: 340, influence: 0.7 },
    { id: 'p11', personId: 133158, name: '林绍山', type: 'person', role: '总工程师', 
      companies: ['c12'], province: '陕西省', city: '榆林市', x: 720, y: 410, influence: 0.8 },
    
    // 能源化工行业人员 - 下方区域
    { id: 'p9', personId: 132133, name: '陈盛霞', type: 'person', role: '副总经理', 
      companies: ['c9', 'c10'], province: '陕西省', city: '榆林市', x: 250, y: 600, influence: 0.8 },
    { id: 'p14', personId: 167890, name: '刘能源', type: 'person', role: '运营总监', 
      companies: ['c15', 'c9'], province: '陕西省', city: '榆林市', x: 325, y: 580, influence: 0.75 },
    { id: 'p10', personId: 142567, name: '杨志华', type: 'person', role: '董事长', 
      companies: ['c11'], province: '陕西省', city: '榆林市', x: 400, y: 510, influence: 0.85 }
  ];

  // 基于真实关系数据的连接（突出跨企业连接关系）
  const shaanxiRelationships = [
    // 核心独立董事的跨企业连接（超图核心特征）
    { source: 'c1', target: 'p1', type: 'independent_director', weight: 0.95, edgeType: 0 },
    { source: 'c4', target: 'p1', type: 'independent_director', weight: 0.9, edgeType: 0 },
    { source: 'c9', target: 'p1', type: 'independent_director', weight: 0.85, edgeType: 0 },
    
    { source: 'c2', target: 'p2', type: 'independent_director', weight: 0.9, edgeType: 0 },
    { source: 'c6', target: 'p2', type: 'independent_director', weight: 0.85, edgeType: 0 },
    { source: 'c12', target: 'p2', type: 'independent_director', weight: 0.8, edgeType: 0 },
    
    // 西安市企业人员关系
    { source: 'c1', target: 'p3', type: 'chairman', weight: 1.0, edgeType: 4 },
    { source: 'c2', target: 'p4', type: 'ceo', weight: 1.0, edgeType: 4 },
    { source: 'c3', target: 'p5', type: 'technical_director', weight: 0.9, edgeType: 3 },
    { source: 'c4', target: 'p5', type: 'technical_director', weight: 0.85, edgeType: 3 },
    
    // 宝鸡市企业人员关系
    { source: 'c6', target: 'p7', type: 'financial_director', weight: 0.8, edgeType: 2 },
    { source: 'c7', target: 'p7', type: 'financial_director', weight: 0.75, edgeType: 2 },
    { source: 'c8', target: 'p8', type: 'vice_manager', weight: 0.8, edgeType: 2 },
    
    // 榆林市企业人员关系
    { source: 'c9', target: 'p9', type: 'vice_manager', weight: 0.8, edgeType: 2 },
    { source: 'c10', target: 'p9', type: 'vice_manager', weight: 0.75, edgeType: 2 },
    { source: 'c11', target: 'p10', type: 'chairman', weight: 1.0, edgeType: 4 },
    { source: 'c12', target: 'p11', type: 'chief_engineer', weight: 0.8, edgeType: 3 },
    
    // 通过独立董事形成的企业间连接（超图特征）
    { source: 'c1', target: 'c4', type: 'independent_director_connection', weight: 0.9, edgeType: 0 },
    { source: 'c1', target: 'c9', type: 'independent_director_connection', weight: 0.85, edgeType: 0 },
    { source: 'c4', target: 'c9', type: 'independent_director_connection', weight: 0.8, edgeType: 0 },
    
    { source: 'c2', target: 'c6', type: 'independent_director_connection', weight: 0.85, edgeType: 0 },
    { source: 'c2', target: 'c12', type: 'independent_director_connection', weight: 0.8, edgeType: 0 },
    { source: 'c6', target: 'c12', type: 'independent_director_connection', weight: 0.75, edgeType: 0 },
    
    // 技术总监跨企业连接
    { source: 'c3', target: 'c4', type: 'technical_director_connection', weight: 0.85, edgeType: 3 },
    
    // 财务总监跨企业连接
    { source: 'c6', target: 'c7', type: 'financial_director_connection', weight: 0.75, edgeType: 2 },
    
    // 副总经理跨企业连接
    { source: 'c9', target: 'c10', type: 'vice_manager_connection', weight: 0.75, edgeType: 2 },
    
    // 同城企业间的业务关系
    { source: 'c1', target: 'c2', type: 'regional_cooperation', weight: 0.4, edgeType: 6 },
    { source: 'c2', target: 'c3', type: 'regional_cooperation', weight: 0.5, edgeType: 6 },
    { source: 'c3', target: 'c4', type: 'regional_cooperation', weight: 0.3, edgeType: 6 },

    { source: 'c6', target: 'c7', type: 'regional_cooperation', weight: 0.4, edgeType: 6 },
    { source: 'c7', target: 'c8', type: 'regional_cooperation', weight: 0.3, edgeType: 6 },
    { source: 'c9', target: 'c10', type: 'regional_cooperation', weight: 0.4, edgeType: 6 },
    { source: 'c11', target: 'c12', type: 'regional_cooperation', weight: 0.3, edgeType: 6 },
    
    // 新增企业人员关系
    { source: 'c13', target: 'p12', type: 'vice_manager', weight: 0.85, edgeType: 2 },
    { source: 'c14', target: 'p13', type: 'technical_director', weight: 0.8, edgeType: 3 },
    { source: 'c3', target: 'p13', type: 'technical_director', weight: 0.75, edgeType: 3 },
    { source: 'c15', target: 'p14', type: 'operations_director', weight: 0.75, edgeType: 2 },
    { source: 'c9', target: 'p14', type: 'operations_director', weight: 0.7, edgeType: 2 },
    
    // 新增企业间连接
    { source: 'c1', target: 'c13', type: 'financial_cooperation', weight: 0.6, edgeType: 6 },
    { source: 'c3', target: 'c14', type: 'technical_cooperation', weight: 0.7, edgeType: 3 },
    { source: 'c9', target: 'c15', type: 'industry_cooperation', weight: 0.8, edgeType: 6 },
    { source: 'c13', target: 'c14', type: 'regional_cooperation', weight: 0.4, edgeType: 6 },
    { source: 'c11', target: 'c15', type: 'regional_cooperation', weight: 0.5, edgeType: 6 }
  ];

  // 状态初始化
  const [companies, setCompanies] = useState(initialCompanies);
  const [persons, setPersons] = useState(initialPersons);

  // 拖拽事件处理函数
  const handleMouseDown = (e, node) => {
    e.preventDefault();
    setIsDragging(true);
    setDraggedNode(node);
    
    const rect = svgRef.current.getBoundingClientRect();
    const offsetX = e.clientX - rect.left - node.x;
    const offsetY = e.clientY - rect.top - node.y;
    setDragOffset({ x: offsetX, y: offsetY });
  };

  const handleMouseMove = (e) => {
    if (!isDragging || !draggedNode) return;
    
    const rect = svgRef.current.getBoundingClientRect();
    const newX = e.clientX - rect.left - dragOffset.x;
    const newY = e.clientY - rect.top - dragOffset.y;
    
    if (draggedNode.type === 'company') {
      setCompanies(prev => prev.map(company => 
        company.id === draggedNode.id 
          ? { ...company, x: newX, y: newY }
          : company
      ));
    } else {
      setPersons(prev => prev.map(person => 
        person.id === draggedNode.id 
          ? { ...person, x: newX, y: newY }
          : person
      ));
    }
  };

  const handleMouseUp = () => {
    setIsDragging(false);
    setDraggedNode(null);
    setDragOffset({ x: 0, y: 0 });
  };

  // 添加全局鼠标事件监听
  useEffect(() => {
    if (isDragging) {
      document.addEventListener('mousemove', handleMouseMove);
      document.addEventListener('mouseup', handleMouseUp);
      
      return () => {
        document.removeEventListener('mousemove', handleMouseMove);
        document.removeEventListener('mouseup', handleMouseUp);
      };
    }
  }, [isDragging, draggedNode, dragOffset]);

  // 陕西省各市超边（根据新布局调整中心坐标）
  const cityHyperedges = {
    '西安市': { 
      companies: ['c1', 'c2', 'c3', 'c4', 'c14'], 
      persons: ['p1', 'p2', 'p3', 'p4', 'p5', 'p13'], 
      color: '#ef4444', 
      center: {x: 435, y: 150} 
    },
    '宝鸡市': { 
      companies: ['c6', 'c7', 'c8'], 
      persons: ['p7', 'p8'], 
      color: '#3b82f6', 
      center: {x: 400, y: 350} 
    },
    '榆林市': { 
      companies: ['c9', 'c10', 'c11', 'c12', 'c15'], 
      persons: ['p9', 'p10', 'p11', 'p14'], 
      color: '#f59e0b', 
      center: {x: 460, y: 535} 
    }
  };

  // 行业超边配置（根据截图实际企业坐标调整中心坐标）
  const industryHyperedges = {
    '金融服务': {
      companies: ['c1'], // 陕国投A (265,155)
      color: '#dc2626', // 高饱和度红色
      center: {x: 265, y: 155}
    },
    '电子设备': {
      companies: ['c2', 'c3', 'c4', 'c14'], // 烽火电子(458,131)、中航飞机(523,127)、彩虹股份(587,166)、合众思壮(654,155)
      color: '#2563eb', // 高饱和度蓝色
      center: {x: 556, y: 145}
    },
    '机械设备': {
      companies: ['c7'], // 建设机械 (390,347)
      color: '#059669', // 高饱和度绿色
      center: {x: 390, y: 347}
    },
    '有色金属': {
      companies: ['c6'], // 宝钛股份 (190,366)
      color: '#f59e0b', // 高饱和度橙色
      center: {x: 190, y: 366}
    },
    '电气设备': {
      companies: ['c8', 'c12'], // 宝光股份(654,371)、中国西电(626,512)
      color: '#7c3aed', // 高饱和度紫色
      center: {x: 640, y: 442}
    },
    '能源化工': {
      companies: ['c9', 'c10', 'c11', 'c15'], // 陕西煤业(334,503)、陕西黑猫(283,578)、延长化建(515,544)、中国神华(459,586)
      color: '#7c2d12', // 高饱和度棕色
      center: {x: 398, y: 553}
    }
  };

  // 关系类型映射
  const edgeTypeMapping = {
    0: { name: '独立董事', color: '#8b5cf6' },
    1: { name: '监事关系', color: '#10b981' },
    2: { name: '财务管理', color: '#f59e0b' },
    3: { name: '技术管理', color: '#06b6d4' },
    4: { name: '高管关系', color: '#ef4444' },
    5: { name: '任职关系', color: '#84cc16' },
    6: { name: '区域合作', color: '#ec4899' },
    7: { name: '竞争关系', color: '#f97316' },
    8: { name: '行业合作', color: '#6366f1' }
  };

  const getNodeColor = (node) => {
    if (node.type === 'company') {
      switch (node.risk) {
        case 'high': return '#ef4444';
        case 'medium': return '#f59e0b';
        case 'low': return '#10b981';
        default: return '#6b7280';
      }
    }
    // 人员节点根据影响力着色
    const influence = node.influence || 0.5;
    if (influence > 0.8) return '#8b5cf6';
    if (influence > 0.6) return '#a78bfa';
    return '#c4b5fd';
  };

  const getRelationshipColor = (relationship) => {
    return edgeTypeMapping[relationship.edgeType]?.color || '#6b7280';
  };

  const filteredCompanies = companies.filter(company => {
    const matchesCategory = selectedCategory === 'all' || company.industry === selectedCategory;
    const matchesRisk = riskLevel === 'all' || company.risk === riskLevel;
    const matchesSearch = searchTerm === '' || 
      company.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      company.stockCode.includes(searchTerm);
    return matchesCategory && matchesRisk && matchesSearch;
  });

  const filteredPersons = persons.filter(person => {
    const matchesSearch = searchTerm === '' || 
      person.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      person.role.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesSearch;
  });

  const NodeTooltip = ({ node, x, y }) => {
    if (!node) return null;
    
    return (
      <div 
        className="absolute bg-white border border-gray-300 rounded-lg shadow-lg p-3 z-10 min-w-64"
        style={{ left: x + 10, top: y - 10 }}
      >
        <div className="font-bold text-sm mb-2">{node.name}</div>
        {node.type === 'company' && (
          <div className="text-xs space-y-1">
            <div className="flex items-center gap-2">
              <Building2 className="w-3 h-3" />
              <span>股票代码: {node.stockCode}</span>
            </div>
            <div className="flex items-center gap-2">
              <TrendingUp className="w-3 h-3" />
              <span>行业: {node.industry}</span>
            </div>
            <div className="flex items-center gap-2">
              <MapPin className="w-3 h-3" />
              <span>地区: {node.city}</span>
            </div>
            <div className="flex items-center gap-2">
              <AlertTriangle className="w-3 h-3" />
              <span>风险等级: {node.risk}</span>
            </div>
          </div>
        )}
        {node.type === 'person' && (
          <div className="text-xs space-y-1">
            <div className="flex items-center gap-2">
              <Users className="w-3 h-3" />
              <span>ID: {node.personId}</span>
            </div>
            <div className="flex items-center gap-2">
              <Shield className="w-3 h-3" />
              <span>职位: {node.role}</span>
            </div>
            <div className="flex items-center gap-2">
              <MapPin className="w-3 h-3" />
              <span>地区: {node.city}</span>
            </div>
            <div className="flex items-center gap-2">
              <Network className="w-3 h-3" />
              <span>影响力: {((node.influence || 0.5) * 100).toFixed(0)}%</span>
            </div>
            <div className="flex items-center gap-2">
              <Building2 className="w-3 h-3" />
              <span>关联企业: {node.companies?.length || 0}个</span>
            </div>
          </div>
        )}
      </div>
    );
  };

  return (
    <div className="w-full h-screen bg-gray-50 flex flex-col">
      {/* 控制面板 */}
      <div className="bg-white border-b border-gray-200 p-4">
        <div className="flex items-center justify-between mb-4">
          <h1 className="text-xl font-bold text-gray-800">陕西省金融风险知识超图可视化系统</h1>
          <div className="flex items-center gap-2 text-sm text-gray-600">
            <Globe className="w-4 h-4" />
            <span>20个企业 • 22个人员 • 9个城市</span>
          </div>
        </div>
        
        <div className="flex items-center gap-4 flex-wrap">
          <div className="flex items-center gap-2">
            <Search className="w-4 h-4 text-gray-500" />
            <input
              type="text"
              placeholder="搜索企业或人员..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="border border-gray-300 rounded px-2 py-1 text-sm w-48"
            />
          </div>
          
          <div className="flex items-center gap-2">
            <label className="text-sm font-medium">行业:</label>
            <select 
              value={selectedCategory} 
              onChange={(e) => setSelectedCategory(e.target.value)}
              className="border border-gray-300 rounded px-2 py-1 text-sm"
            >
              <option value="all">全部</option>
              <option value="金融服务">金融服务</option>
              <option value="电子设备">电子设备</option>
              <option value="机械设备">机械设备</option>
              <option value="医疗服务">医疗服务</option>
              <option value="航空装备">航空装备</option>
              <option value="化工原料">化工原料</option>
            </select>
          </div>
          
          <div className="flex items-center gap-2">
            <label className="text-sm font-medium">风险:</label>
            <select 
              value={riskLevel} 
              onChange={(e) => setRiskLevel(e.target.value)}
              className="border border-gray-300 rounded px-2 py-1 text-sm"
            >
              <option value="all">全部</option>
              <option value="high">高风险</option>
              <option value="medium">中风险</option>
              <option value="low">低风险</option>
            </select>
          </div>
          
          <div className="flex items-center gap-2">
            <label className="text-sm font-medium">超边类型:</label>
            <select 
              value={hyperedgeType} 
              onChange={(e) => setHyperedgeType(e.target.value)}
              className="border border-gray-300 rounded px-2 py-1 text-sm"
            >
              <option value="city">城市超边</option>
              <option value="industry">行业超边</option>
              <option value="both">双重超边</option>
            </select>
          </div>
        </div>
      </div>

      {/* 主要可视化区域 */}
      <div className="flex-1 flex">
        {/* 左侧图例 */}
        <div className="w-64 bg-white border-r border-gray-200 p-4 overflow-y-auto">
          <h3 className="font-bold text-sm mb-3">图例说明</h3>
          
          <div className="space-y-4">
            <div>
              <h4 className="font-medium text-xs mb-2">节点类型</h4>
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <Building2 className="w-4 h-4 text-blue-500" />
                  <span className="text-xs">企业 (20个)</span>
                </div>
                <div className="flex items-center gap-2">
                  <Users className="w-4 h-4 text-purple-500" />
                  <span className="text-xs">人员 (22个)</span>
                </div>
              </div>
            </div>

            <div>
              <h4 className="font-medium text-xs mb-2">风险等级</h4>
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 bg-red-500 rounded-full"></div>
                  <span className="text-xs">高风险</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 bg-yellow-500 rounded-full"></div>
                  <span className="text-xs">中风险</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 bg-green-500 rounded-full"></div>
                  <span className="text-xs">低风险</span>
                </div>
              </div>
            </div>

            <div>
              <h4 className="font-medium text-xs mb-2">关系类型</h4>
              <div className="space-y-1 text-xs max-h-32 overflow-y-auto">
                {Object.entries(edgeTypeMapping).map(([type, info]) => (
                  <div key={type} className="flex items-center gap-2">
                    <div className="w-4 h-0.5" style={{ backgroundColor: info.color }}></div>
                    <span>{info.name}</span>
                  </div>
                ))}
              </div>
            </div>

            <div>
              <h4 className="font-medium text-xs mb-2">城市分布</h4>
              <div className="space-y-1 text-xs max-h-40 overflow-y-auto">
                {Object.entries(cityHyperedges).map(([city, info]) => (
                  <div key={city} className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <div className="w-3 h-3 rounded-full" style={{ backgroundColor: info.color }}></div>
                      <span className="text-xs">{city}</span>
                    </div>
                    <span className="text-xs text-gray-500">
                      {info.companies.length}企业
                    </span>
                  </div>
                ))}
              </div>
            </div>

            <div>
              <h4 className="font-medium text-xs mb-2">行业分布</h4>
              <div className="space-y-1 text-xs max-h-40 overflow-y-auto">
                {Object.entries(industryHyperedges).map(([industry, info]) => (
                  <div key={industry} className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <div className="w-3 h-3 rounded-full" style={{ backgroundColor: info.color }}></div>
                      <span className="text-xs">{industry}</span>
                    </div>
                    <span className="text-xs text-gray-500">
                      {info.companies.length}企业
                    </span>
                  </div>
                ))}
              </div>
            </div>

            <div>
              <h4 className="font-medium text-xs mb-2">数据统计</h4>
              <div className="text-xs space-y-1 bg-gray-50 p-2 rounded">
                <div>筛选企业: {filteredCompanies.length}/14</div>
                <div>显示人员: {filteredPersons.length}/13</div>
                <div>关系总数: {shaanxiRelationships.length}条</div>
                <div>覆盖城市: 3个</div>
                <div>核心行业: 6个</div>
              </div>
            </div>
          </div>
        </div>

        {/* 中心超图可视化 */}
        <div className="flex-1 relative">
          <svg 
            ref={svgRef} 
            width="100%" 
            height="100%" 
            className="bg-gray-50"
            viewBox="0 0 900 700"
          >
            {/* 城市超边背景 - 平滑不规则形状 */}
            {(hyperedgeType === 'city' || hyperedgeType === 'both') && Object.entries(cityHyperedges).map(([city, info]) => {
              // 根据城市动态计算形状大小，基于实际企业分布
              let width = 180, height = 140;
              if (city === '西安市') {
                width = 600; // x范围570像素(150-720)，适当放大覆盖
                height = 100; // y范围60像素(120-180)，适当放大覆盖
              } else if (city === '宝鸡市') {
                width = 680; // x范围640像素(80-720)，适当放大覆盖
                height = 100; // y范围60像素(320-380)，适当放大覆盖
              } else if (city === '榆林市') {
                width = 560; // x范围520像素(200-720)，适当放大覆盖
                height = 200; // y范围170像素(450-620)，适当放大覆盖
              }
              
              // 生成平滑不规则形状的SVG路径
              const generateOrganicPath = (cx: number, cy: number, w: number, h: number) => {
                const points = [];
                const numPoints = 8; // 控制点数量
                const angleStep = (2 * Math.PI) / numPoints;
                
                for (let i = 0; i < numPoints; i++) {
                  const angle = i * angleStep;
                  // 添加随机变化使形状更自然
                  const radiusVariation = 0.8 + Math.sin(angle * 3) * 0.2 + Math.cos(angle * 5) * 0.1;
                  const rx = (w / 2) * radiusVariation;
                  const ry = (h / 2) * radiusVariation;
                  
                  const x = cx + rx * Math.cos(angle);
                  const y = cy + ry * Math.sin(angle);
                  points.push({ x, y });
                }
                
                // 使用贝塞尔曲线创建平滑路径
                let path = `M ${points[0].x} ${points[0].y}`;
                
                for (let i = 0; i < points.length; i++) {
                  const current = points[i];
                  const next = points[(i + 1) % points.length];
                  const nextNext = points[(i + 2) % points.length];
                  
                  // 计算控制点
                  const cp1x = current.x + (next.x - points[(i - 1 + points.length) % points.length].x) * 0.2;
                  const cp1y = current.y + (next.y - points[(i - 1 + points.length) % points.length].y) * 0.2;
                  const cp2x = next.x - (nextNext.x - current.x) * 0.2;
                  const cp2y = next.y - (nextNext.y - current.y) * 0.2;
                  
                  path += ` C ${cp1x} ${cp1y}, ${cp2x} ${cp2y}, ${next.x} ${next.y}`;
                }
                
                path += ' Z';
                return path;
              };
              
              const organicPath = generateOrganicPath(info.center.x, info.center.y, width, height);
              
              return (
                <g key={city}>
                  <path
                    d={organicPath}
                    fill={info.color}
                    opacity="0.1"
                    stroke={info.color}
                    strokeWidth="2"
                    strokeDasharray="5,5"
                  />
                  <text
                    x={info.center.x}
                    y={info.center.y - height/2 - 10}
                    textAnchor="middle"
                    className="text-lg font-bold"
                    fill={info.color}
                  >
                    {city}
                  </text>
                  {/* 调试：显示超边中心点 */}
                  <circle
                    cx={info.center.x}
                    cy={info.center.y}
                    r="3"
                    fill="red"
                    stroke="white"
                    strokeWidth="1"
                  />
                  <text
                    x={info.center.x + 10}
                    y={info.center.y + 5}
                    className="text-xs fill-red-600 font-mono"
                  >
                    中心({info.center.x},{info.center.y})
                  </text>
                </g>
              );
            })}

            {/* 行业超边背景 - 平滑不规则形状，高饱和度颜色 */}
            {(hyperedgeType === 'industry' || hyperedgeType === 'both') && Object.entries(industryHyperedges).map(([industry, info]) => {
              // 根据行业动态计算形状大小（基于新布局）
              let width = 200, height = 150;
              if (industry === '金融服务') {
                 width = 120; // 包含1个企业，左上角紧凑区域
                 height = 100;
              } else if (industry === '电子设备') {
                width = 280; // 包含4个企业，右上角区域
                height = 180;
              } else if (industry === '有色金属') {
                width = 120; // 包含1个企业，左侧中部
                height = 100;
              } else if (industry === '机械设备') {
                width = 200; // 包含2个企业，中部区域
                height = 120;
              } else if (industry === '电气设备') {
                width = 200; // 包含2个企业，扩大覆盖范围
                height = 250; // 增加高度以覆盖中国西电
              } else if (industry === '能源化工') {
                width = 300; // 包含4个企业，下方区域
                height = 200;
              }
              
              // 生成平滑不规则形状的SVG路径（复用城市超边的函数）
              const generateOrganicPath = (cx: number, cy: number, w: number, h: number) => {
                const points = [];
                const numPoints = 8; // 控制点数量
                const angleStep = (2 * Math.PI) / numPoints;
                
                for (let i = 0; i < numPoints; i++) {
                  const angle = i * angleStep;
                  // 添加随机变化使形状更自然
                  const radiusVariation = 0.8 + Math.sin(angle * 3) * 0.2 + Math.cos(angle * 5) * 0.1;
                  const rx = (w / 2) * radiusVariation;
                  const ry = (h / 2) * radiusVariation;
                  
                  const x = cx + rx * Math.cos(angle);
                  const y = cy + ry * Math.sin(angle);
                  points.push({ x, y });
                }
                
                // 使用贝塞尔曲线创建平滑路径
                let path = `M ${points[0].x} ${points[0].y}`;
                
                for (let i = 0; i < points.length; i++) {
                  const current = points[i];
                  const next = points[(i + 1) % points.length];
                  const nextNext = points[(i + 2) % points.length];
                  
                  // 计算控制点
                  const cp1x = current.x + (next.x - points[(i - 1 + points.length) % points.length].x) * 0.2;
                  const cp1y = current.y + (next.y - points[(i - 1 + points.length) % points.length].y) * 0.2;
                  const cp2x = next.x - (nextNext.x - current.x) * 0.2;
                  const cp2y = next.y - (nextNext.y - current.y) * 0.2;
                  
                  path += ` C ${cp1x} ${cp1y}, ${cp2x} ${cp2y}, ${next.x} ${next.y}`;
                }
                
                path += ' Z';
                return path;
              };
              
              const organicPath = generateOrganicPath(info.center.x, info.center.y, width, height);
              
              return (
                <g key={`industry-${industry}`}>
                  <path
                    d={organicPath}
                    fill={info.color}
                    opacity="0.15"
                    stroke={info.color}
                    strokeWidth="3"
                    strokeDasharray="10,5"
                  />
                  <text
                    x={info.center.x}
                    y={info.center.y - height/2 - 25}
                    textAnchor="middle"
                    className="text-sm font-bold"
                    fill={info.color}
                    style={{
                      textShadow: '1px 1px 2px rgba(255,255,255,0.8), -1px -1px 2px rgba(255,255,255,0.8)',
                      fontSize: '14px'
                    }}
                  >
                    {industry}
                  </text>
                </g>
              );
            })}

            {/* 关系连线 */}
            {shaanxiRelationships.map((rel, index) => {
              const sourceNode = [...filteredCompanies, ...filteredPersons].find(n => n.id === rel.source);
              const targetNode = [...filteredCompanies, ...filteredPersons].find(n => n.id === rel.target);
              
              if (!sourceNode || !targetNode) return null;
              
              return (
                <line
                  key={index}
                  x1={sourceNode.x}
                  y1={sourceNode.y}
                  x2={targetNode.x}
                  y2={targetNode.y}
                  stroke={getRelationshipColor(rel)}
                  strokeWidth={rel.weight * 2 + 1}
                  opacity={0.6}
                />
              );
            })}

            {/* 企业节点 */}
            {filteredCompanies.map((company) => (
              <g key={company.id}>
                <circle
                  cx={company.x}
                  cy={company.y}
                  r="20"
                  fill={getNodeColor(company)}
                  stroke="white"
                  strokeWidth="3"
                  opacity={hoveredNode === company.id ? 1 : 0.8}
                  className={isDragging ? "cursor-grabbing" : "cursor-grab"}
                  onMouseEnter={() => setHoveredNode(company.id)}
                  onMouseLeave={() => setHoveredNode(null)}
                  onMouseDown={(e) => handleMouseDown(e, company)}
                  onClick={() => !isDragging && setSelectedNode(company)}
                />
                <Building2 
                  x={company.x - 8} 
                  y={company.y - 8} 
                  width="16" 
                  height="16" 
                  fill="white"
                  className="pointer-events-none"
                />
                <text
                  x={company.x}
                  y={company.y + 35}
                  textAnchor="middle"
                  className="text-xs font-medium fill-gray-700"
                >
                  {company.name.length > 6 ? company.name.substring(0, 6) + '...' : company.name}
                </text>
                <text
                  x={company.x}
                  y={company.y + 47}
                  textAnchor="middle"
                  className="text-xs fill-gray-500"
                >
                  {company.stockCode}
                </text>
                {/* 调试信息：显示坐标和城市 */}
                <text
                  x={company.x}
                  y={company.y + 59}
                  textAnchor="middle"
                  className="text-xs fill-blue-600 font-mono"
                >
                  ({company.x},{company.y})
                </text>
                <text
                  x={company.x}
                  y={company.y + 71}
                  textAnchor="middle"
                  className="text-xs fill-red-600"
                >
                  {company.city}
                </text>
              </g>
            ))}

            {/* 人员节点 */}
            {filteredPersons.map((person) => (
              <g key={person.id}>
                <circle
                  cx={person.x}
                  cy={person.y}
                  r={14 + (person.influence || 0.5) * 8}
                  fill={getNodeColor(person)}
                  stroke="white"
                  strokeWidth="2"
                  opacity={hoveredNode === person.id ? 1 : 0.8}
                  className={isDragging ? "cursor-grabbing" : "cursor-grab"}
                  onMouseEnter={() => setHoveredNode(person.id)}
                  onMouseLeave={() => setHoveredNode(null)}
                  onMouseDown={(e) => handleMouseDown(e, person)}
                  onClick={() => !isDragging && setSelectedNode(person)}
                />
                <Users 
                  x={person.x - 7} 
                  y={person.y - 7} 
                  width="14" 
                  height="14" 
                  fill="white"
                  className="pointer-events-none"
                />
                <text
                  x={person.x}
                  y={person.y + 30}
                  textAnchor="middle"
                  className="text-xs fill-gray-700"
                >
                  {person.name}
                </text>
                <text
                  x={person.x}
                  y={person.y + 42}
                  textAnchor="middle"
                  className="text-xs fill-gray-500"
                >
                  {person.role}
                </text>
              </g>
            ))}
          </svg>

          {/* 工具提示 */}
          {hoveredNode && (
            <NodeTooltip
              node={[...filteredCompanies, ...filteredPersons].find(n => n.id === hoveredNode)}
              x={300}
              y={200}
            />
          )}
        </div>

        {/* 右侧详情面板 */}
        <div className="w-80 bg-white border-l border-gray-200 p-4 overflow-y-auto">
          <h3 className="font-bold text-sm mb-3">详细信息</h3>
          
          {selectedNode ? (
            <div className="space-y-4">
              <div>
                <h4 className="font-medium text-sm mb-2">{selectedNode.name}</h4>
                <div className="text-xs text-gray-600 space-y-1">
                  <div>类型: {selectedNode.type === 'company' ? '企业' : '人员'}</div>
                  {selectedNode.stockCode && <div>代码: {selectedNode.stockCode}</div>}
                  {selectedNode.personId && <div>ID: {selectedNode.personId}</div>}
                  {selectedNode.industry && <div>行业: {selectedNode.industry}</div>}
                  {selectedNode.role && <div>职位: {selectedNode.role}</div>}
                  {selectedNode.city && <div>城市: {selectedNode.city}</div>}
                  {selectedNode.risk && <div>风险: {selectedNode.risk}</div>}
                  {selectedNode.influence && <div>影响力: {(selectedNode.influence * 100).toFixed(0)}%</div>}
                </div>
              </div>

              <div>
                <h4 className="font-medium text-sm mb-2">关联关系</h4>
                <div className="space-y-1 text-xs">
                  {shaanxiRelationships
                    .filter(rel => rel.source === selectedNode.id || rel.target === selectedNode.id)
                    .map((rel, index) => {
                      const isSource = rel.source === selectedNode.id;
                      const otherNodeId = isSource ? rel.target : rel.source;
                      const otherNode = [...filteredCompanies, ...filteredPersons].find(n => n.id === otherNodeId);
                      
                      if (!otherNode) return null;
                      
                      return (
                        <div key={index} className="flex items-center gap-2 p-2 bg-gray-50 rounded">
                          <div 
                            className="w-2 h-2 rounded-full"
                            style={{ backgroundColor: getRelationshipColor(rel) }}
                          ></div>
                          <div className="flex-1">
                            <div className="font-medium">{otherNode.name}</div>
                            <div className="text-gray-500">
                              {edgeTypeMapping[rel.edgeType]?.name || rel.type} 
                              {rel.weight && ` (${(rel.weight * 100).toFixed(0)}%)`}
                            </div>
                          </div>
                        </div>
                      );
                    })}
                </div>
              </div>

              {selectedNode.type === 'person' && selectedNode.companies && (
                <div>
                  <h4 className="font-medium text-sm mb-2">关联企业</h4>
                  <div className="space-y-1 text-xs">
                    {selectedNode.companies.map(companyId => {
                      const company = filteredCompanies.find(c => c.id === companyId);
                      return company ? (
                        <div key={companyId} className="p-2 bg-blue-50 rounded">
                          <div className="font-medium">{company.name}</div>
                          <div className="text-gray-500">{company.stockCode} • {company.industry}</div>
                        </div>
                      ) : null;
                    })}
                  </div>
                </div>
              )}

              <div>
                <h4 className="font-medium text-sm mb-2">城市超边</h4>
                {selectedNode.city && cityHyperedges[selectedNode.city] && (
                  <div className="p-2 rounded" style={{ backgroundColor: cityHyperedges[selectedNode.city].color + '20' }}>
                    <div className="text-xs font-medium">{selectedNode.city}</div>
                    <div className="text-xs text-gray-600 mt-1">
                      该城市共有 {cityHyperedges[selectedNode.city].companies.length} 家企业
                    </div>
                  </div>
                )}
              </div>

              {selectedNode.industry && industryHyperedges[selectedNode.industry] && (
                <div>
                  <h4 className="font-medium text-sm mb-2">行业超边</h4>
                  <div className="p-2 rounded" style={{ backgroundColor: industryHyperedges[selectedNode.industry].color + '20' }}>
                    <div className="text-xs font-medium">{selectedNode.industry}</div>
                    <div className="text-xs text-gray-600 mt-1">
                      该行业共有 {industryHyperedges[selectedNode.industry].companies.length} 家企业
                    </div>
                  </div>
                </div>
              )}
            </div>
          ) : (
            <div className="text-sm text-gray-500">
              点击节点查看详细信息
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default ShaanxiHypergraph;